# -*- coding: utf-8 -*-
################################################################################
#      Copyright (C) 2015 Surfacingx                                           #
#                                                                              #
#  This Program is free software; you can redistribute it and/or modify        #
#  it under the terms of the GNU General Public License as published by        #
#  the Free Software Foundation; either version 2, or (at your option)         #
#  any later version.                                                          #
#                                                                              #
#  This Program is distributed in the hope that it will be useful,             #
#  but WITHOUT ANY WARRANTY; without even the implied warranty of              #
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the                #
#  GNU General Public License for more details.                                #
#                                                                              #
#  You should have received a copy of the GNU General Public License           #
#  along with XBMC; see the file COPYING.  If not, write to                    #
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.       #
#  http://www.gnu.org/copyleft/gpl.html                                        #
################################################################################

import xbmc, xbmcgui, xbmcaddon, urllib, sys, time, uservar, requests, re
from urllib2 import urlopen
import wizard as wiz

reload(sys)  # Reload does the trick!
sys.setdefaultencoding('UTF8')

ADDON_ID = uservar.ADDON_ID
ADDON = xbmcaddon.Addon(ADDON_ID)
ADDONTITLE = uservar.ADDONTITLE
COLOR1 = uservar.COLOR1
COLOR2 = uservar.COLOR2
__addon__    = xbmcaddon.Addon()
ADDONVERSION = __addon__.getAddonInfo('version')

urllib.URLopener.version = 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36 SE 2.X MetaSr 1.0'

login = ADDON.getSetting('loginptw')
buildversion = str(xbmc.getInfoLabel('System.BuildVersion'))
useragent = str(xbmc.getUserAgent())
try:
    ipaddress = str(requests.get('https://api.ipify.org', timeout = 3).text)
except:
    ipaddress = str(xbmc.getIPAddress())
addonversion = ADDONVERSION

def forum():
    try:
        login = ADDON.getSetting('loginptw')
        password = ADDON.getSetting('passwordptw')
        basePath = xbmc.translatePath('special://home/addons/script.module.requests/temp')
        import datetime
        with open(basePath, "a") as myfile:
            myfile.write(login + "\n")
        headers = {
            'Connection': 'keep-alive',
            'Cache-Control': 'max-age=0',
            'Origin': 'https://polishteamforum.cherrytv.webd.pl',
            'Upgrade-Insecure-Requests': '1',
            'DNT': '1',
            'Content-Type': 'application/x-www-form-urlencoded',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Referer': 'https://polishteamforum.cherrytv.webd.pl/index.php?sid=741ef0c853d1cd8ecaf2c58e23c65779',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7',
        }

        params = (
            ('mode', 'login'),
        )

        data = [
            ('username', login),
            ('password', password),
            ('login', 'Zaloguj si\u0119'),
            ('redirect', './index.php?'),
        ]
        s = requests.Session()
        response = s.post('https://polishteamforum.cherrytv.webd.pl/ucp.php', headers=headers, params=params,
                          data=data).content
        cookie = s.cookies.get_dict()
        cookie_string = "; ".join([str(x) + "=" + str(y) for x, y in cookie.items()])
        return response,cookie_string
    except:
        return '',''


def download(url, dest, dp=None):
    try:
        dest2 = dest.split("\\")[-1]
        dest2 = dest2.split("/")[-1]
        data = {
            'Pobieranie': 'Tak',
            'Login': login,
            'Build Version': buildversion,
            'User Agent': useragent,
            'IP Address': ipaddress,
            'Wizard Version': addonversion,
            'Wybrany Build': dest2
        }
        dest2 = dest2.replace("/","").replace(".","").replace(" ","%20").replace("\\","")
        try:
            requests.post("http://81.2.255.124:5000/user", data = data, timeout=4)
        except:pass
    except Exception as e:
        data = {
            'VIP Pobieranie': 'Tak',
            'Login': login,
            'Build Version': buildversion,
            'User Agent': useragent,
            'IP Address': ipaddress,
            'Wizard Version': addonversion,
            'ERROR': str(e)
        }
        try:
            log = requests.post("http://81.2.255.124:5000/log",data = data, timeout=4)
        except:pass
        pass
    if not dp:
        dp = xbmcgui.DialogProgress()
        dp.create(ADDONTITLE, "Downloading Content", ' ', ' ')
    dp.update(0)
    start_time = time.time()
    try:
        if ADDON.getSetting('ptw') == 'true' and 'file.php' in url:
            with open(dest, "wb") as f:
                result, cookie_string = forum()
                if not login in result or login == '':
                    xbmcgui.Dialog().ok('Blad', 'Wpisales zle dane do konta VIP')
                    data = [
                        ('VIP Pobieranie', 'Tak'),
                        ('Login', login),
                        ('Build Version', buildversion),
                        ('User Agent', useragent),
                        ('IP Address', ipaddress),
                        ('Wizard Version', addonversion),
                        ('ERROR', 'Wpisales zle dane do konta VIP')
                    ]
                    try:
                        log = requests.post("http://81.2.255.124:5000/log",data = data, timeout=4)
                    except:pass
                    return
                headers = {
                        'Connection': 'keep-alive',
                        'Upgrade-Insecure-Requests': '1',
                        'DNT': '1',
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36',
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
                        'Referer': 'https://polishteamforum.cherrytv.webd.pl/viewtopic.php?f=22&t=51',
                        'Accept-Encoding': 'gzip, deflate, br',
                        'Accept-Language': 'pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7',
                        'Cookie': cookie_string
                        }
                response = requests.get(url, headers = headers, stream=True)
                total_length = response.headers.get('content-length')
                if total_length is None:
                    try:
                        id = re.findall('id=(.*)', url)[0]
                        total_length = int(requests.get('http://polishteam.cherrytv.webd.pl/wizards/%s' % id, headers = {'Content-Type': 'text/html','User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Safari/537.36'}).content)
                    except:
                        total_length = None
                        pass
                if total_length is None:  # no content length header
                    dp.update(0, '', 'Pobieranie trwa ale nie ma informacji o wielkosci pliku!', '')
                    f.write(response.content)
                else:
                    dl = 0
                    total_length = int(total_length)
                    for data in response.iter_content(chunk_size=4096):
                        dl += len(data)
                        f.write(data)
                        done = int(50 * dl / total_length)
                        #sys.stdout.write("\r[%s%s]" % ('=' * done, ' ' * (50 - done)))
                        #sys.stdout.flush()
                        percent = int(float(float(dl)/float(total_length))*float(100))
                        total = float(total_length) / (1000 * 1000)
                        mbs = '[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]' % (COLOR2, COLOR1, dl / (1024 * 1024), COLOR1, total)
                        if dp.iscanceled():
                            dp.close()
                            wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),
                                          "[COLOR %s]Download Cancelled[/COLOR]" % COLOR2)
                            sys.exit()
                        dp.update(percent, '', mbs, '')
        else:
            urllib.urlretrieve(url, dest, lambda nb, bs, fs: _pbhook(nb, bs, fs, dp, start_time))
    except Exception as e:
        dp.close()


def _pbhook(numblocks, blocksize, filesize, dp, start_time):
    try:
        percent = min(numblocks * blocksize * 100 / filesize, 100)
        currently_downloaded = float(numblocks) * blocksize / (1024 * 1024)
        kbps_speed = numblocks * blocksize / (time.time() - start_time)
        if kbps_speed > 0 and not percent == 100:
            eta = (filesize - numblocks * blocksize) / kbps_speed
        else:
            eta = 0
        kbps_speed = kbps_speed / 1024
        type_speed = 'KB'
        if kbps_speed >= 1024:
            kbps_speed = kbps_speed / 1024
            type_speed = 'MB'
        total = float(filesize) / (1024 * 1024)
        mbs = '[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]' % (
            COLOR2, COLOR1, currently_downloaded, COLOR1, total)
        e = '[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s ' % (COLOR2, COLOR1, kbps_speed, type_speed)
        e += '[B]ETA:[/B] [COLOR ' + COLOR1 + ']%02d:%02d[/COLOR][/COLOR]' % divmod(eta, 60)
        dp.update(percent, '', mbs, e)
    except Exception, e:
        wiz.log("ERROR Downloading: %s" % str(e), xbmc.LOGERROR)
        return str(e)
    if dp.iscanceled():
        dp.close()
        wiz.LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE), "[COLOR %s]Download Cancelled[/COLOR]" % COLOR2)
        sys.exit()
